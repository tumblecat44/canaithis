#!/usr/bin/env bash
# Builds Supabase connection strings for CanAIThis production.
# Default: malgun-staging-20260601 (cbuwyfyhiibobgygpkxv) — reserved project slot.
set -euo pipefail

REF="${SUPABASE_PROJECT_REF:-cbuwyfyhiibobgygpkxv}"
REGION_HOST="${SUPABASE_POOLER_HOST:-aws-1-ap-northeast-2.pooler.supabase.com}"

if [[ -f "${CANAITHIS_ENV:-}" ]]; then
  # shellcheck disable=SC1090
  source "$CANAITHIS_ENV"
elif [[ -f "${MALGUN_ENV:-$HOME/malgun-res/.env.supabase.local}" ]]; then
  # shellcheck disable=SC1090
  source "${MALGUN_ENV:-$HOME/malgun-res/.env.supabase.local}"
  REF="${CANAITHIS_SUPABASE_REF:-cbuwyfyhiibobgygpkxv}"
fi

: "${SUPABASE_DB_PASSWORD:?Set SUPABASE_DB_PASSWORD}"

# Pooler usernames contain a dot; Prisma must see postgres%2E{ref} in the URL.
POOLER_USER="postgres%2E${REF}"

# Session pooler (5432) for migrations; transaction pooler (6543) for the app runtime.
export DIRECT_URL="postgresql://${POOLER_USER}:${SUPABASE_DB_PASSWORD}@${REGION_HOST}:5432/postgres"
export DATABASE_URL="postgresql://${POOLER_USER}:${SUPABASE_DB_PASSWORD}@${REGION_HOST}:6543/postgres?pgbouncer=true"